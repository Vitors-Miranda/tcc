<?php

namespace App\Models;

class ListarProdutos{
    
    public static function select()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        $idProduto = self::getID();

        $sql = "SELECT * FROM produto_pedido WHERE fk_pedido_id = $idProduto";
        $stmt = $connPDO->query($sql);
        $pedidos = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $produtos["nome"] = [];
        $produtos["quantidade"] = [];

        foreach($pedidos as $pedido){
            $sql = "SELECT * FROM produtos WHERE id_produto = $pedido->fk_produto_id";
            $stmt = $connPDO->query($sql);
            array_push($produtos["nome"], $stmt->fetch(\PDO::FETCH_OBJ)->nome_produto);
            array_push($produtos["quantidade"], $pedido->qtd);
        }
        return $produtos;
    }
    private static function getID()
    {
        $domains = explode("/", $_SERVER["REQUEST_URI"]);
        $index = sizeof($domains)-1;
        return $domains[$index];
    }
}