<?php
namespace App\Models;

use App\Models\Uploader;

class UpdateProduto {
    public static function update($dados){
        session_start();
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        $id = $dados['id'];
        $sqlConsulta = "SELECT * FROM produtos WHERE id_produto = $id";
        $stmtConsulta = $connPDO->query($sqlConsulta);
        $produtos = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $caminho_antigo = $produtos->caminho_imagem;
        $caminho_antigo = explode("/", $caminho_antigo, 3);

        $id = $_SESSION['id_usuario'];
        $sqlConsulta = "SELECT * FROM usuarios WHERE id_usuario = $id";
        $stmtConsulta= $connPDO->query($sqlConsulta);
        $usuario = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $estabelecimento = $usuario->id_estabelecimento;

        if (!empty($_FILES['imgUpdate'])) {
            $upload = new Uploader($_FILES['imgUpdate'], 600, 400, __DIR__ . "/../../img/{$estabelecimento}/");
            $caminho = $upload->salvar();
            $sql = "UPDATE produtos SET nome_produto = :nome, descricao = :descricao, preco = :preco, caminho_imagem = '$caminho' WHERE id_produto = :id";        
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":id", $dados['id']);
            $stmt->bindValue(":nome", $dados['nome']);
            $stmt->bindValue(":descricao", $dados['descricao']);
            $stmt->bindValue(":preco", $dados['preco']);
            $stmt->execute();
            if(isset($caminho_antigo[2]) && file_exists($caminho_antigo[2])){
                unlink($caminho_antigo[2]);
            }     
        }else{
            $sql = "UPDATE produtos SET nome_produto = :nome, descricao = :descricao, preco = :preco WHERE id_produto = :id";        
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":id", $id);
            $stmt->bindValue(":nome", $dados['nome']);
            $stmt->bindValue(":descricao", $dados['descricao']);
            $stmt->bindValue(":preco", $dados['preco']);
            $stmt->execute();
        }
        

        if ($stmt->rowCount() > 0) {
            return "Produto atualizado com sucesso!";
        } else {
            return $dados;
        }
    }
}

