<?php
namespace App\Models;

class Sair
{
    public static function sair()
    {
        session_start();
        session_destroy();
    }
}