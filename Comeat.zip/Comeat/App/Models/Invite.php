<?php

namespace App\Models;

class Invite
{
    public static function generate()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $estabelecimento = $_SESSION['id_estabelecimento'];
        $inviteCode = self::generateCode();

        $sql = "UPDATE estabelecimentos SET invite_code = :code, data_remocao_codigo_convite = ADDTIME(NOW(), '00:15:00') WHERE id_estabelecimento = :eid";
        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":code", $inviteCode);
        $stmt->bindValue(":eid", $estabelecimento);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            return $inviteCode;
        } else {
            return "Falha ao gerar código";
        }
    }

    public static function entry($code)
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $usuario = $_SESSION["id_usuario"];
        $estabelecimento = self::getEstabelecimento($code);
        if ($estabelecimento) {
            $sql = "UPDATE usuarios SET id_estabelecimento = :eid WHERE id_usuario = :uid";
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":eid", $estabelecimento);
            $stmt->bindValue(":uid", $usuario);
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                $_SESSION['id_estabelecimento'] = $estabelecimento;
                return true;
            } else {
                return false;
            }
        } else {
            return \false;
        }
    }

    private static function getEstabelecimento($codigo)
    {

        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        $sql = "SELECT id_estabelecimento FROM estabelecimentos WHERE invite_code LIKE :code";
        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":code", $codigo);
        $stmt->execute();
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        if ($stmt->rowCount() > 0) {
            return $result->id_estabelecimento;
        } else {
            return false;
        }
    }
    private static function generateCode()
    {
        return "C" . substr(uniqid(rand()), 0, 3) . "{$_SESSION['id_estabelecimento']}";
    }
}
