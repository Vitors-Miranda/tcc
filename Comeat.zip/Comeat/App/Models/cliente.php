<?php

namespace App\Models;

\error_reporting(\E_ALL);

class Cliente
{
    public static function select()
    {
        session_start();
        $subdominio = self::getSubdomain();
        if ($subdominio) {
            $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
            $sql = "SELECT * FROM produtos INNER JOIN estabelecimentos ON produtos.id_estabelecimento = estabelecimentos.id_estabelecimento WHERE estabelecimentos.subdominio LIKE :subdominio";
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":subdominio", $subdominio);
            $stmt->execute();
            $produtos = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            return $produtos;
        } else {
            return "Estabelecimento não encontrado";
        }
    }
    private static function getSubdomain()
    {

        $domains = explode("/", $_SERVER["REQUEST_URI"]);
        $index = sizeof($domains)-1;
        return $domains[$index];
    }
}
