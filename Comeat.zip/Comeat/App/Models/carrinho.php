<?php

namespace App\Models;

class Carrinho{
    
    public static function insert($data)
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        session_start();

            $domains = explode("/", $_SERVER["REQUEST_URI"]);
            $index = sizeof($domains)-1;
            $subdominio = $domains[$index];


            $sqlEst = "SELECT * FROM estabelecimentos WHERE subdominio = '$subdominio'";
            $stmtEst = $connPDO->query($sqlEst);
            $empresa = $stmtEst->fetch(\PDO::FETCH_OBJ);
            $id_estabelecimento = $empresa->id_estabelecimento;
            $preco_total = $_SESSION['carrinho']['preco_total'];
            if(isset($data['logradouro']) && !empty($data['logradouro'])){
                $delivery = 1;
            }else{
                $delivery = 0;
            }
            $sql = "INSERT INTO pedido VALUES (0, NOW(), :preco, $delivery, :nome, :telefone, :bairro, :logradouro, :numero, :estabelecimento, 0)";
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":nome", $data['nomePedido']);
            $stmt->bindValue(":preco", $preco_total);
            $stmt->bindValue(":estabelecimento", $id_estabelecimento);
           
            $stmt->bindValue(":telefone", $data['telefone']);
            $stmt->bindValue(":bairro", $data['bairro']);
            $stmt->bindValue(":logradouro", $data['logradouro']);
            $stmt->bindValue(":numero", $data['numero']);
            $stmt->execute();   
            
            $last_id = $connPDO->lastInsertId();  
            for ($i=0; $i < count($_SESSION['idProdutos']); $i++) { 
                $idAtual = $_SESSION['idProdutos'][$i];
                $quantidadeAtual = $_SESSION['carrinho'][$idAtual]['quantidade'];
                $sqlPP = "INSERT INTO produto_pedido VALUES(0, $last_id, $idAtual, $quantidadeAtual)";
                $stmtPP = $connPDO->prepare($sqlPP);
                $stmtPP->execute();
            }
            session_destroy();
            return "pedido efetuado com sucesso!";
        }

        public static function delete($data)
    {
        session_start();
        $preco = $_SESSION['carrinho'][$data['id']]['preco'];
        $qtd = $_SESSION['carrinho'][$data['id']]['quantidade'];
        
        $_SESSION['carrinho'][$data['id']]['preco']=0;
        $_SESSION['carrinho'][$data['id']]['quantidade']=0;

        $_SESSION['carrinho']['quantidade_total'] -= $qtd;
        $_SESSION['carrinho']['preco_total'] -= $preco;

        return  $_SESSION['carrinho'];
        }
    }
            