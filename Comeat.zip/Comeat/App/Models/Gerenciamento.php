<?php

namespace App\Models;

class Gerenciamento {

    public static function select(){
    $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
    session_start();

    $id = $_SESSION['id_usuario'];
    $sqlConsulta = "SELECT * FROM usuarios WHERE id_usuario = $id";
    $stmtConsulta = $connPDO->query($sqlConsulta);
    $user = $stmtConsulta->fetch(\PDO::FETCH_OBJ);

    if($user->id_estabelecimento != null){
        $estabelecimento = $user->id_estabelecimento;   
        $sql = "SELECT * FROM pedido WHERE fk_empresa_id = $estabelecimento ORDER BY data";
        $stmt = $connPDO->query($sql);
        $pedidos = $stmt->fetchAll(\PDO::FETCH_OBJ);
        return $pedidos;    
        }else{
            return null;
        }
    }
}