<?php

namespace App\Models;

class Pedido{
    
    public static function insert($data)
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        if(isset($data['idProduto'])){
            $idProduto = $data['idProduto'];
            $sqlConsulta = "SELECT * FROM produtos WHERE id_produto = $idProduto";
            $stmtConsulta = $connPDO->query($sqlConsulta);
            $produtos = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
            $valor = $produtos->preco;
            $nome = $produtos->nome_produto;
            $preco = $valor*$data['qtd'];

            session_start();
            //armazenando os ids
            if(isset($_SESSION['idProdutos'])){
                if(!in_array($idProduto, $_SESSION['idProdutos'])){
                    array_push($_SESSION['idProdutos'], $idProduto);
                }
            }else{
                $_SESSION['idProdutos'] = [$idProduto];
            }
            //armazenando o preco total
            if(isset($_SESSION['carrinho']['preco_total'])){
                $_SESSION['carrinho']['preco_total'] += $preco;
            }else{
                $_SESSION['carrinho']['preco_total'] = $preco;
            }
            //armazenando a quantidade total
            if(isset($_SESSION['carrinho']['quantidade_total'])){
                $_SESSION['carrinho']['quantidade_total'] += $data['qtd'];
            }else{
                $_SESSION['carrinho']['quantidade_total'] = $data['qtd'];
            }

            if(isset($_SESSION['carrinho'][$idProduto])){
                $_SESSION['carrinho'][$idProduto]['quantidade'] += $data['qtd'];
                $_SESSION['carrinho'][$idProduto]['preco'] += $preco;
            }else{
                $_SESSION['carrinho'][$idProduto] = array('quantidade'=>$data['qtd'],'preco'=>$preco, 'nome'=>$nome);  
            }
            $carrinho = $_SESSION['carrinho'];
            return $carrinho;
        }
    }

    public static function select()
    {
        session_start();
        session_destroy();
    }

    public static function update($data){
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        $id = $data['id'];
        $sqlConsulta = "SELECT * FROM pedido WHERE id_pedido = $id";
        $stmtConsulta = $connPDO->query($sqlConsulta);
        $pedido = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $feito = $pedido->Feito;

        if($feito == 1){
            $feito = 0;
            $botao = "Feito";
        }else{
            $feito = 1;
            $botao = "Desfazer";
        }
        $sql = "UPDATE pedido SET feito = $feito WHERE id_pedido = $id";
        $stmt = $connPDO->prepare($sql);
        $stmt->execute();
        return $botao;
    }
}