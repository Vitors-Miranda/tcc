<?php

namespace App\Models;

class Estabelecimento
{

    public static function insert($data)
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $usuario = $_SESSION['id_usuario'];
        $sqlVerifica = "SELECT * FROM usuarios WHERE id_usuario = $usuario";
        $stmtVerifica = $connPDO->query($sqlVerifica);
        $user_est = $stmtVerifica->fetch(\PDO::FETCH_OBJ);
        $VerificaEst = $user_est->id_estabelecimento;

        if ($VerificaEst == null || $VerificaEst == 0) {
            
            $sql = 'INSERT INTO estabelecimentos VALUES(0, :nome, null, null, null, null, null)';
            $stmt = $connPDO->prepare($sql);
            $stmt->bindValue(":nome", $data['criarest']);
            $stmt->execute();

            $sqlSelect = "SELECT COUNT(*) FROM estabelecimentos";
            $stmtSelect = $connPDO->query($sqlSelect);
            $estabelecimento = $stmtSelect->fetchColumn();

            mkdir(__DIR__ . '/../../img/' . $estabelecimento . '/', 0777, true);

            $sqlUpdate = 'UPDATE usuarios SET id_estabelecimento = :estabelecimento WHERE id_usuario = :usuario';
            $stmtUpdate = $connPDO->prepare($sqlUpdate);
            $stmtUpdate->bindValue(":estabelecimento", $estabelecimento);
            $stmtUpdate->bindValue(":usuario", $usuario);
            $stmtUpdate->execute();
            
            if ($stmt->rowCount() > 0) {
                return "<div class='text-success'><i class='bi bi-check-circle-fill'></i> Estabelecimento cadastrado!</div>";
            } else {
                return "<div class='text-danger'><i class='bi bi-x-circle-fill'></i> Erro ao cadastrar.</div>";
            }
        } else {
            $cadastrado = 1;
            return $cadastrado;
        }

        $connPDO = null;
    }

    public static function select()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $usuario = $_SESSION['id_usuario'];
        $sqlVerifica = "SELECT * FROM usuarios WHERE id_usuario = $usuario";
        $stmtVerifica = $connPDO->query($sqlVerifica);
        $user_est = $stmtVerifica->fetch(\PDO::FETCH_OBJ);
        $VerificaEst = $user_est->id_estabelecimento;
        if ($VerificaEst != null && $VerificaEst != 0) {
            $sqlSelect = "SELECT * FROM estabelecimentos WHERE id_estabelecimento = $VerificaEst";
            $stmtSelect = $connPDO->query($sqlSelect);
            $_SESSION['estabelecimento'] = $stmtSelect->fetch(\PDO::FETCH_OBJ);
            $_SESSION['cadastrado'] = 1;
        } else {
            $_SESSION['cadastrado'] = 0;
        }
        return $_SESSION;
        $connPDO = null;
    }

    public static function update($data){
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $id = $_SESSION['id_usuario'];
        $sqlConsulta = "SELECT * FROM usuarios WHERE id_usuario = $id";
        $stmtConsulta= $connPDO->query($sqlConsulta);
        $usuario = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $estabelecimento = $usuario->id_estabelecimento;
        $sql = "UPDATE estabelecimentos SET nome = :nome, pix_key = :pix, subdominio = :subdominio WHERE id_estabelecimento = $estabelecimento";
        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":nome", $data['nomeEst']);
        $stmt->bindValue(":pix", $data['pix']);
        $stmt->bindValue(":subdominio", $data['subdominio']);
        $stmt->execute();
        
        if($stmt->rowCount() > 0){
            return "Atualizado com sucesso!";
        }else{
            return "Algo deu errado";
        }
    }
}
