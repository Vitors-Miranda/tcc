<?php

namespace App\Models;


class Subdominio
{
    public static function get()
    {
        session_start();
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        $id= $_SESSION["id_usuario"];
        $sqlConsulta = "SELECT * FROM usuarios WHERE id_usuario = $id";
        $stmtConsulta= $connPDO->query($sqlConsulta);
        $usuario = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $estabelecimento = $usuario->id_estabelecimento;
        $_SESSION["id_estabelecimento"] = $estabelecimento;
        
        $sql = "SELECT * FROM estabelecimentos WHERE id_estabelecimento = :eid";
        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":eid", $estabelecimento);
        $stmt->execute();
        $subdominio = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($stmt->rowCount() > 0) {
            return $subdominio["subdominio"];
        } else {
            return false;
        }
    }

    // public static function update($subdominio)
    // {
    //     session_start();
    //     $estabelecimento = $_SESSION["id_estabelecimento"];
    //     $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
    //     $sql = "UPDATE estabelecimentos SET subdominio = :subdominio WHERE id_estabelecimento = :eid";
    //     $stmt = $connPDO->prepare($sql);
    //     $stmt->bindValue(":subdominio", $subdominio);
    //     $stmt->bindValue(":eid", $estabelecimento);
    //     if ($stmt->execute()) {
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }
}
