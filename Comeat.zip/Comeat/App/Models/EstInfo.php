<?php

namespace App\Models;

class EstInfo
{
    public static function select()
    {
        session_start();
        $subdominio = self::getSubdomain();
        if ($subdominio) {
            $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

            $sqlEstabelecimento = "SELECT * FROM estabelecimentos WHERE subdominio = '$subdominio'";
            $stmtEstabelecimento = $connPDO->query($sqlEstabelecimento);
            $estabelecimento = $stmtEstabelecimento->fetch(\PDO::FETCH_OBJ);
            return $estabelecimento;
        } else {
            return "Estabelecimento não encontrado";
        }
    }
    
    private static function getSubdomain()
    {

        $domains = explode("/", $_SERVER["REQUEST_URI"]);
        $index = sizeof($domains)-1;
        return $domains[$index];
    }
}

