<?php

namespace App\Models;

class Funcionario
{
    public static function select()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $usuario = $_SESSION['id_usuario'];

        $sqlSelect = "SELECT COUNT(*) FROM estabelecimentos";
        $stmtSelect = $connPDO->query($sqlSelect);
        $_SESSION["id_estabelecimento"] = $stmtSelect->fetchColumn();
        $estabelecimento = $_SESSION['id_estabelecimento'];
        $sql = "SELECT 
                    id_usuario AS codigo,
                    nome       AS nome,
                    1          AS perfil,
                    online     AS online
                FROM 
                    usuarios u
                WHERE 
                    u.id_usuario <> :id_u
                AND
                    u.id_estabelecimento = :id_e
                ";
        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":id_u", $usuario);
        $stmt->bindValue(":id_e", $estabelecimento);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_OBJ);
        if ($stmt->rowCount() > 0) {
            return $result;
        } else {
            return "Nenhum funcionário encontrado";
        }
    }
}
