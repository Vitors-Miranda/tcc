<?php

namespace App\Models;

use App\Models\Uploader;

class Produto
{
    public static function save($dados)
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);

        session_start();
        $usuario = $_SESSION["id_usuario"];
        $sqlEst = "SELECT * FROM usuarios WHERE id_usuario = $usuario";
        $stmtEst = $connPDO->query($sqlEst);
        $user = $stmtEst->fetch(\PDO::FETCH_OBJ);
        $estabelecimento = $user->id_estabelecimento;
        if (!empty($_FILES['img'])) {
            $upload = new Uploader($_FILES['img'], 600, 400, __DIR__ . "/../../img/{$_SESSION['id_estabelecimento']}/");
            $caminho = $upload->salvar();
        }
        $sql = "INSERT INTO
                    produtos
                VALUES
                    (
                        0, :id_estabelecimento, :id_usuario_cadastrou, null, :nome, :descricao, :preco, NOW(), null, '$caminho'
                    ) 
                ";

        $stmt = $connPDO->prepare($sql);
        $stmt->bindValue(":id_estabelecimento", $estabelecimento);
        $stmt->bindValue(":id_usuario_cadastrou", $usuario);
        $stmt->bindValue(":nome", $dados["nome"]);
        $stmt->bindValue(":descricao", $dados["descricao"]);
        $stmt->bindValue(":preco", $dados["preco"]);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return "Produto cadastrado com sucesso";
        } else {
            return $caminho;
        }
    }

    public static function select()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        session_start();
        $usuario = $_SESSION["id_usuario"];
        $sqlEst = "SELECT * FROM usuarios WHERE id_usuario = $usuario";
        $stmtEst = $connPDO->query($sqlEst);
        $user = $stmtEst->fetch(\PDO::FETCH_OBJ);
        $estabelecimento = $user->id_estabelecimento;

        $sql = "SELECT * FROM produtos WHERE id_estabelecimento = $estabelecimento";
        $stmt = $connPDO->query($sql);
        $produtos = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $produtos;
    }
    public static function delete($data)
    {
        $connPDO = new \PDO(DBDRIVE. ':host='. DBHOST. ';dbname='. DBNAME, DBUSER, DBPASS);
        session_start();
        $id = $data['id'];
        $sqlConsulta = "SELECT * FROM produtos WHERE id_produto = $id";
        $stmtConsulta = $connPDO->query($sqlConsulta);
        $produtos = $stmtConsulta->fetch(\PDO::FETCH_OBJ);
        $caminho_antigo = $produtos->caminho_imagem;
        $caminho_antigo = explode("/", $caminho_antigo, 3);
        if(isset($caminho_antigo[2]) && file_exists($caminho_antigo[2])){
            unlink($caminho_antigo[2]);
        }
            $sql= "DELETE FROM produtos WHERE id_produto = $id";
            $stmt = $connPDO->prepare($sql);
            $stmt->execute();
        }

    }
