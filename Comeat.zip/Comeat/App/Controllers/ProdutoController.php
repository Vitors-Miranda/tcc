<?php

namespace App\Controllers;

use App\Models\Produto;

class ProdutoController
{
    public static function post()
    {
        return Produto::save($_POST);
    }
    public static function get()
    {
        return Produto::select();
    }
    public static function delete(){
        $_DELETE = json_decode(file_get_contents('php://input'), true);
        return Produto::delete($_DELETE); 
    }
}
