<?php

namespace App\Controllers;

use App\Models\listarProdutos;

class ListarProdutosController{

    public static function get(){
        return listarProdutos::select();
    }
    
}