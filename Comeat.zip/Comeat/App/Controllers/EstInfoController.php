<?php

namespace App\Controllers;
use App\Models\EstInfo;

class EstInfoController{
    public static function get(){
        return EstInfo::select();
    }
}