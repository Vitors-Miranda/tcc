<?php

namespace App\Controllers;

use App\Models\Funcionario;

class FuncionarioController
{
    public static function get()
    {
        return Funcionario::select();
    }
}
