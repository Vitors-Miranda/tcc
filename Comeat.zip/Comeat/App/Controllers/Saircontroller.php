<?php


namespace App\Controllers;
use App\Models\Sair;

class SairController{
    public static function get(){
        return Sair::sair();
    }
}