<?php

namespace App\Controllers;
use App\Models\Estabelecimento;

class EstabelecimentoController{
    public static function post(){
        return Estabelecimento::insert($_POST);
    }
    public static function get(){
        return Estabelecimento::select();
    }
    public static function put(){
        $_PUT = json_decode(file_get_contents('php://input'), true);
        return Estabelecimento::update($_PUT); 
    }
}