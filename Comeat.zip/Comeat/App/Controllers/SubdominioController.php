<?php

namespace App\Controllers;

use App\Models\Subdominio;

class SubdominioController
{
    public static function get()
    {
        return Subdominio::get();
    }
}
