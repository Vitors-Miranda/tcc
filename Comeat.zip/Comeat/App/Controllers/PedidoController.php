<?php

namespace App\Controllers;

use App\Models\Pedido;

class PedidoController
{
    public static function post()
    {
        return Pedido::insert($_POST);
    }
    public static function get()
    {
        return Pedido::select();
    }
    public static function put(){
        $_PUT = json_decode(file_get_contents('php://input'), true);
        return Pedido::update($_PUT); 
    }
}
