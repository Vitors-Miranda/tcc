<?php

namespace App\Controllers;

use App\Models\UpdateProduto;

class UpdateProdutoController
{
    public static function post()
    {
        return UpdateProduto::update($_POST);
    }
}