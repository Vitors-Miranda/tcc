<?php

namespace App\Controllers;

use App\Models\Cliente;

class ClienteController
{
    public static function get()
    {
        return Cliente::select();
    }
}
