<?php

namespace App\Controllers;

use App\Models\Gerenciamento;

class GerenciamentoController{

    public static function get(){
        return Gerenciamento::select();
    }
    
}