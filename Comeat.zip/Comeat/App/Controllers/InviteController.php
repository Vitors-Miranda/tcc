<?php

namespace App\Controllers;

use App\Models\Invite;

class InviteController
{
    public static function get()
    {
        return Invite::generate();
    }

    public static function post()
    {
        return Invite::entry($_POST["code"]);
    }
}
