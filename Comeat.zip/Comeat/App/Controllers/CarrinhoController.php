<?php

namespace App\Controllers;

use App\Models\Carrinho;

class CarrinhoController
{
    public static function post()
    {
        return Carrinho::insert($_POST);
    }
    public static function delete(){
        $_DELETE = json_decode(file_get_contents('php://input'), true);
        return Carrinho::delete($_DELETE); 
    }
}
