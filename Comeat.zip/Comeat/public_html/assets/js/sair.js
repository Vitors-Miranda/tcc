const btnsair = document.getElementById("btnsair")
let sair = false;
const webservice = "http://"+EnderecoLink+"public_html/api/sair/"
function requisitarLogin(metodo, funcao) {
    fetch(webservice, {
        method: metodo
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}

btnsair.addEventListener("click", () => {
    requisitarLogin("GET", (respostaLogin) => {
        window.location.href = "login.html"
    })
})
