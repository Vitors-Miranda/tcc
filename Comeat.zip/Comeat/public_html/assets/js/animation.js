//a animação é responsável por trocar o texto da página inicial, 
//colocando sua opacidade em 0 e depois surgindo o texto!

    let invertido = false
    setInterval(() => {
        titulo.style.opacity=0
    }, 4150)
    //troca de texto
    setInterval(() => {
        titulo.style.opacity=1
        if (invertido == true) {
            titulo.innerHTML = "<h1>Virtualize seu <span class='dourado'>comércio</span>. Mantenha seus clientes <span class='dourado'>atualizados</span></h1>"
            invertido = false;
        } else {
            titulo.innerHTML = "<h1>Monte seu catálogo e tenha <span class='dourado'>controle</span> dos produtos.</h1>"
            invertido = true;
        }
    }, 4500)
