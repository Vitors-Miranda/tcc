
const formcheck = document.getElementById("formcheck")

function check(id){
    const pedidoLink = "http://"+EnderecoLink+"public_html/api/pedido"
    function updatepedido(dados, metodo, funcao) {
        fetch(pedidoLink, {
            method: metodo,
            body: dados
        }).then(responseCadProduto => responseCadProduto.json()).then(
            (responseCadProduto) => {
                funcao(responseCadProduto)
            }
        )
    }
    updatepedido(JSON.stringify({
        id: id
    }), "PUT", returned => {
        listar()
        modalElemento.hide()
    })
}