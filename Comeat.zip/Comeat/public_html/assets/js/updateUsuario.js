const nomeUsuario = document.getElementById("nomeUser")
const sobrenomeUsuario = document.getElementById("sobrenome")

function requisitar(metodo, dados, funcao) {
    fetch(usuarioLink, {
        method: metodo,
        body: JSON.stringify({
            nome: dados[0],
            sobrenome: dados[1]
        })
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
)}
dados = [0,0]
updateUser.addEventListener("submit", (e)=>{
    e.preventDefault()
    dados[0] = nomeUsuario.value
    dados[1] = sobrenomeUsuario.value
    requisitar("PUT", dados, (retorno)=>{
        console.log(retorno.data)
        toastbody.innerHTML = retorno.data
        toastElement.show()
    })
})

