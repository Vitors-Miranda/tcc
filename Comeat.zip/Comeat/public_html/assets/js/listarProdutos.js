
function Produtos(metodo, dados, funcao){
    fetch(productLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}

function UpdateProdutos(metodo, dados, funcao){
    fetch(UpdateproductLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
let modalATT = document.getElementById("modalatualizar")
let opitions = {
    focus:true
} 
let modalatualizar = new bootstrap.Modal(modalATT,opitions)

const cards= document.getElementById("cards")
document.addEventListener("DOMContentLoaded", ()=>{
    listar()
})  

function listar(){
    cards.innerHTML= ""
    Produtos("GET", null, (retorno) => {
        retorno.data.forEach(element => {
            let caminhoArray = element.caminho_imagem.split("/")
            let caminho = `../../img/${caminhoArray[4]}/${caminhoArray[5]}`
            cards.innerHTML+=`<div class='card'><a href="javascript:produtos(${element.id_produto}, '${element.nome_produto}','${element.descricao}', '${caminho}', ${element.preco})"> <img src='${caminho}' class='card-img-top' alt='...'><div class='card-body'><p class='card-text'> ${element.nome_produto} </p></div> <div class="card-footer text-muted" style='font-size:0.8rem;'>
            R$ ${element.preco}
          </div></a></div>` 
        })
    })
}

function produtos(id, nome, descricao , caminho, preco){
    modalATT.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <form id="formAtualizarProduto">
            <input type="hidden" id="id" name="id" value="${id}">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="staticBackdropLabel">Atualizar Produto</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="row">
                            </div>
                            <div class="row">
                                <div class="text-center">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text" id="titulomodal"><i
                                                class="bi bi-pencil-square"></i></span>
                                        <input type="text" class="form-control" name="nome" id="attnome" placeholder="Titulo: " value="${nome}">
                                    </div>
                                </div>
                                <div class="text-center">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text" id="descricaomodal"><i
                                                class="bi bi-file-earmark-text"></i></span>
                                        <input type="text" class="form-control" name="descricao" id="attdescricao"
                                            placeholder="Descrição: "value="${descricao}">
                                    </div>
                                </div>
                                <div class="text-center">
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text" id="variacaomodal"><i
                                                class="bi bi-bookmark"></i></span>
                                        <input type="text" list="tags" class="form-control" name="variacao"
                                            placeholder="Variação: ">
                                    </div>
                                </div>
                                <div class="form-label-group my-3" id="imagemUpdate">
                                <input type="file" name="imgUpdate" id ="imgUpdate" class="form-control">
                                </div>
                                <div class="row">
                                    <div class="input-group input-group-sm p-3">
                                        <span class="input-group-text" id="moneyspan">R$</span>
                                        <input type="number" id="attpreco" class="form-control" name="preco"
                                            placeholder="0,00" step=".01" value= "${preco.toFixed(2)}">
                                    </div>
                                </div>
                                <div class="row">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="submit" class="btn btn-outline-dark" id="btnSalvar">Salvar</button>
                        <a href="javascript:excluirProduto(${id})" class="btn btn-outline-alert">Excluir</a>
                    </div>
                </div>
            </form>
        </div>
`
modalatualizar.show()

const atualizarProduto = document.getElementById("formAtualizarProduto")


atualizarProduto.addEventListener("submit", (e)=> {
    e.preventDefault()
    dados = new FormData(atualizarProduto)

    UpdateProdutos("POST", dados, (retorno)=>{
        console.log(retorno.data)
        listar()
        modalatualizar.hide()
    })
})

}

function excluirProduto(id){
    Produtos("DELETE", JSON.stringify({
        id: id
    }), (retorno) => {
        console.log(retorno.data)
        listar()
        modalatualizar.hide()
    })
}