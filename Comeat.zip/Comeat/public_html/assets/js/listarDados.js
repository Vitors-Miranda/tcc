const usuarioLink = "http://"+EnderecoLink+"public_html/api/usuario/"

const nomeUser = document.getElementById("nomeUser")
const sobrenome = document.getElementById("sobrenome");
const email = document.getElementById("email");
const senha = document.getElementById("senha");

function ListarDados(metodo, funcao){
    fetch(usuarioLink, {
        method: metodo
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
document.addEventListener("DOMContentLoaded", ()=>{
    listar()
})  

function listar(){
    ListarDados("GET", (retorno) => {
        nomeUser.value = retorno.data.nome
        sobrenome.value = retorno.data.sobrenome
        email.value = retorno.data.email
    })
}