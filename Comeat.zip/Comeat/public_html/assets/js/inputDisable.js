const btnCriar = document.getElementById("btncriar");
const criarest=  document.getElementById("criarest");

criarest.addEventListener("input", ()=>{
    if(criarest.value != 0){
        btnCriar.disabled = false
    }else{
        btnCriar.disabled = true
    }
})