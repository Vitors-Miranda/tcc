let modalHTML = document.getElementById("modalempresa")
let opitions = {
    focus:true
} 
let modalElement = new bootstrap.Modal(modalHTML,opitions)


