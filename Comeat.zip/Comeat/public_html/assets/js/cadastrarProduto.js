
const productLink = "http://"+EnderecoLink+"public_html/api/produto"
const UpdateproductLink = "http://"+EnderecoLink+"public_html/api/updateproduto"

function requestSaveProduct(dados, metodo, funcao) {
    fetch(productLink, {
        method: metodo,
        body: dados
    }).then(responseCadProduto => responseCadProduto.json()).then(
        (responseCadProduto) => {
            funcao(responseCadProduto)
        }
    )
}
const options = {
    focus: true
}
const modalproduto = new bootstrap.Modal('#modalproduto', options)

var formCadastroProduto = document.getElementById("formCadastroProduto")
formCadastroProduto.addEventListener("submit", e => {
    modalproduto.hide()
    e.preventDefault()
    dados = new FormData(formCadastroProduto)
    requestSaveProduct(dados, "POST", returned => {
        listar()
    })
})