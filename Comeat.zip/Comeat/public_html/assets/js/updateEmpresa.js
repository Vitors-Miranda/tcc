const EmpresaLink = "http://"+EnderecoLink+"public_html/api/estabelecimento/"

function requisitarSubdomain(metodo, dados, funcao) {
    fetch(EmpresaLink, {
        method: metodo,
        body: JSON.stringify({
            nomeEst: dados[0],
            pix: dados[1],
            subdominio: dados[2]
        })
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
)}
dados = [0,0,0]

updateEst.addEventListener("submit", (e)=>{
    e.preventDefault()
    dados[0] = nomeEst.value
    dados[1] = pix.value
    dados[2] = subdominio.value
    
    requisitarSubdomain("PUT", dados, (retorno)=>{
        console.log(retorno.data)
        toastbody.innerHTML = retorno.data
        toastElement.show()
    })
})

