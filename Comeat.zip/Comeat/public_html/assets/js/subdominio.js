// var formConfig = document.getElementById("updateEst")

// // formConfig.addEventListener('submit', e => {
// //     e.preventDefault()
// //     let dados = new FormData(formConfig)
// //     requestSubdomain(dados, "POST", (resposta) => {
// //         if (resposta.data) {
// //             sendToDisplaySubdomain()
// //         }
// //     })
// // })

// function requestSubdomain(dados, metodo, funcao) {
//     fetch("http://"+EnderecoLink+"public_html/api/subdominio", {
//         method: metodo,
//         body: dados
//     }).then(response => response.json()).then(
//         (response) => {
//             funcao(response)
//         }
//     )
// }


// function sendToDisplaySubdomain() {
//     requestSubdomain(null, "GET", (response) => {
//         if (response.data) {
//             document.getElementById("subdomain").value = response.data
//         }
//     })
// }
// sendToDisplaySubdomain()