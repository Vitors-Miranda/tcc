const gerenciamentoLink = "http://"+EnderecoLink+"public_html/api/gerenciamento/"
const listaPedido = document.getElementById("listaPedido")
const listaConcluido = document.getElementById("listaConcluido")
let modalPedido = document.getElementById(`modalpedido`)
let modalElemento = new bootstrap.Modal(modalPedido, opitions)
let mensagem 
function requisitarGerenciamento (metodo, dados, funcao){
    fetch(gerenciamentoLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
document.addEventListener("DOMContentLoaded", ()=> {
    listar()
})

function pedido(id, nome, hora, telefone, delivery, bairro, rua, numero) {
    function ListarPedidos (metodo, dados, funcao){
        fetch(`http://${EnderecoLink}public_html/api/listarProdutos/${id}`, {
            method: metodo,
            body: dados
        }).then(resposta => resposta.json()).then(
            (retorno) => {
                funcao(retorno)
            }
        )
    }
    let endereco
    if(delivery == 1){
        mensagem = "Delivery"
        endereco = `
        
        <div class="input-group mb-3">
            <span class="input-group-text" id="bairro">Bairro</span>
            <input type="text" class="form-control" placeholder="bairro" aria-label="bairro" aria-describedby="bairro" value = "${bairro}" disabled>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text" id="Rua">Rua</span>
            <input type="text" class="form-control" placeholder="Rua" aria-label="Rua" aria-describedby="Rua" value = "${rua}" disabled>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text" id="numero">Número</span>
            <input type="text" class="form-control" placeholder="numero" aria-label="numero" aria-describedby="numero" value = "${numero}" disabled>
        </div>
        `
    }else{
        mensagem = "Retirada na loja"
        endereco = ""
    }
    modalPedido.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="staticBackdropLabel">${nome}</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <table class="table mt-3">
                            <thead>
                                <tr>
                                    <th scope="col">Produto</th>
                                    <th scope="col">Qtd</th>
                                </tr>
                            </thead>
                            <tbody id="tableProdutos">
                            </tbody>
                        </table>
                        <hr>
                        <div class="text-center">
                        <h6>
                        Detalhes do pedido (${mensagem})
                        </h6>
                        <div class="input-group my-3">
                        <span class="input-group-text" id="telefone">Telefone</span>
                        <input type="text" class="form-control" placeholder="telefone" aria-label="telefone" aria-describedby="telefone" value = "${telefone}" disabled>
                    </div>
                        <div id="endereco" class="">
                        ${endereco}
                        </div>
                        </div>
                        </div>
                    </div>
                        <div class="modal-footer justify-content-between">                    
                            <a href="javascript:check(${id})"><button class="btn" type="submit" id="btnfeito">Pronto</button></a>
                            ${hora}
                        </div>
                    
                </div>
            </div>
        `
        modalElemento.show()
        let nomePedido = []
        let qtdPedido = []

        const tableProdutos = document.getElementById("tableProdutos")
        ListarPedidos("GET", null, (retorno)=> {
            tableProdutos.innerText = ""
            retorno.data["nome"].forEach( element =>{
                nomePedido.push(element)
            })
            retorno.data["quantidade"].forEach( element =>{
                qtdPedido.push(element)
            })
            for(i=0; i<nomePedido.length; i++){
                tableProdutos.innerHTML += `
                <tr>
                    <th scope="row">${nomePedido[i]}</th>
                    <td>${qtdPedido[i]}</td>
                </tr>
                `
            }
            
        })
}

function listar(){
    requisitarGerenciamento("GET", null, (retorno)=> {
        console.log(retorno.data)
        listaPedido.innerHTML= ""
        listaConcluido.innerHTML= ""
        if(retorno.data != null){
            retorno.data.forEach(element => {
                if(element.delivery == 0){
                    mensagem = "<i class='bi bi-shop'></i>"
                }else{
                    mensagem = "<i class='bi bi-truck'></i>"
                }
                hora = element.data.split(" ");
                hora = hora[1]
                if(element.Feito != 1){
                    listaPedido.innerHTML += `
                    <a href="javascript:pedido('${element.id_pedido}', '${element.nome}', '${hora}', '${element.telefone}', ${element.delivery}, '${element.bairro}', '${element.logradouro}','${element.numero}')">
                    <div id="pedidoBox" class="bg-light shadow-sm row rounded w-100 mb-2">
                                <div class="col-5 d-flex justify-content-center align-items-center">
                                    <h6>
                                        ${element.nome}
                                    </h6>
                                </div>
                                <div class="col-4 d-flex justify-content-center align-items-center" style = "font-size: 10px; color:grey;">
                                        ${hora}
                                </div>
                                <div class="col-3 d-flex justify-content-center align-items-center" style = "font-size: 12px; color:grey;">
                                        <b>${mensagem}</b>
                                </div>
                            </div>
                            </a>
                    `
                }else{
                    listaConcluido.innerHTML += `
                    <a href="javascript:pedido('${element.id_pedido}', '${element.nome}', '${hora}', '${element.telefone}')">
                    <div id="pedidoBox" class="bg-light shadow-sm row rounded w-100 mb-2">
                                <div class="col-5 d-flex justify-content-center align-items-center">
                                    <h6>
                                        ${element.nome}
                                    </h6>
                                </div>
                                <div class="col-4 d-flex justify-content-center align-items-center" style = "font-size: 10px; color:grey;">
                                        ${hora}
                                </div>
                                <div class="col-3 d-flex justify-content-center align-items-center" style = "font-size: 12px; color:grey;">
                                        <b>${mensagem}</b>
                                </div>
                            </div>
                            </a>
                    `
                }
            })
        }
    })
}