const inviteLink = "http://"+EnderecoLink+"public_html/api/Invite"
const btnConvite = document.getElementById("inviteCode")
const CodigoBody = document.getElementById("modalBody")

let modalHTML = document.getElementById("modalcodigo")
let opitions = {
    focus:true
} 
let modalElement = new bootstrap.Modal(modalHTML,opitions)

btnConvite.addEventListener("click", () => {
    generateCodeEstabelecimento("GET", (response) => {
        if (response.data) {
            CodigoBody.innerHTML = response.data
            modalElement.show()
        }
    })
})


function generateCodeEstabelecimento(metodo, funcao) {
    fetch(inviteLink, {
        method: metodo
    }).then(response => response.json()).then(
        (response) => {
            funcao(response)
        }
    )
}