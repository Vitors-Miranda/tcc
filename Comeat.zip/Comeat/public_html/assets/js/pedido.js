let item = 0
const body = document.querySelector('body')
const txtitem = document.getElementById("txtitem")
const txtvalor = document.getElementById("txtvalor")
const btnPedir = document.getElementById("btnPedir")
let modalHTML = document.getElementById(`modalpedido`)
let idproduto = document.getElementById("idproduto")
let quantidadeEnviada = document.getElementById("quantidadeEnviada")
let formPedir = document.getElementById("formPed")
let opitions = {
    focus: true
}
let modalElement = new bootstrap.Modal(modalHTML, opitions)
let vetorProdutos = []
    

const nomePedido = document.getElementById("nomePedido")
const telefone = document.getElementById("telefone")
const bairro = document.getElementById("bairro")
const logradouro = document.getElementById("logradouro")
const numero = document.getElementById("numero")


const pedidoLink = "http://"+EnderecoLink+"public_html/api/pedido/" +parametro[1]
const carrinhoLink = "http://"+EnderecoLink+"public_html/api/carrinho/"+parametro[1]

function requisitarPedido(metodo, dados, funcao) {
    fetch(pedidoLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
function requisitarCarrinho(metodo, dados, funcao) {
    fetch(carrinhoLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}

function pedido(id, nome, caminho, preco) {
    modalHTML.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="staticBackdropLabel">${nome}</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="formPedido">
                        <div class="modal-body d-flex justify-content-center align-items-center flex-column">
                            <img src='${caminho}' width='80%'>
                            <div class="input-group input-group-sm m-5 w-75">
                                <span class="input-group-text">
                                <i class="bi bi-currency-dollar"></i>
                                </span>
                                <input type="number" class="form-control" placeholder="Preço" id="preco" name='preco' value="${preco.toFixed(2)}" readonly>
                                <span class="input-group-text">
                                <i class="bi bi-basket"></i>
                                </span>
                                <input type="number" class="form-control" placeholder="Quantidade" id="qtd" name="qtd">
                                <input type="hidden" name="idProduto" id="idproduto" value='${id}'>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-end">
                        <button type="submit" class="btn btn-outline-dark" id="btnPedido">Pedido</button>
                        </div>
                    </form>
                </div>
            </div>
        `
    modalElement.show()
    let tablePedido = document.getElementById("tablePedido");
    let formPedido = document.getElementById("formPedido")

    //listando carrinho caso dê refresh na página
    formPedido.addEventListener("submit", (e) => {
        e.preventDefault()
        modalElement.hide()
        //verificar se há o id no vetor
        let index = vetorProdutos.findIndex(indice => indice === id)

        if(index == -1){
            //se ainda não tiver, ele adiciona
            vetorProdutos.push(id)
        }
        let dados = new FormData(formPedido)
        //zerando os campos antes da listagem
        tablePedido.innerHTML = ""
        txtitem.value = ""
        txtvalor.value = ""
        
        
        requisitarPedido("POST", dados, (retorno) => {

        //ele repete a listagem até usar todos ID's armazenados no array
        for(i = 0; i < vetorProdutos.length; i++){
            txtitem.value = retorno.data['quantidade_total']
            txtvalor.value = "R$ "+ retorno.data['preco_total'].toFixed(2)
            tablePedido.innerHTML += `
            <tr>
                <th scope="row">${retorno.data[vetorProdutos[i]].nome}</th>
                <td>${retorno.data[vetorProdutos[i]].quantidade}</td>
                <td>R$ ${retorno.data[vetorProdutos[i]].preco.toFixed(2)}</td>
                <td class="text-center" style="color:var(--dourado);"><a href="javascript:remover(${vetorProdutos[i]})"> <i class="bi bi-trash"></i> </a> </td>
            </tr>
            `
        }
        })
    })
}

let modalClienteHTML = document.getElementById(`modalcliente`)
let modalCliente = new bootstrap.Modal(modalClienteHTML, opitions)



formPedir.addEventListener("submit", (e) => {
    e.preventDefault()
    modalCliente.hide()
    dados = new FormData(formPedir)

    if (vetorProdutos[0]) {
        requisitarCarrinho("POST", dados, (retorno) => {
            console.log(retorno.data)
            toastbody.innerHTML = retorno.data
            toastElement.show()
        })
    }
    //limpando
    nomePedido.value = ""
    telefone.value = ""
    bairro.value = ""
    logradouro.value = ""
    numero.value = ""
    tablePedido.innerHTML = ""
    txtitem.value = ""
    txtvalor.value = ""
})

function remover (id){
    let index = vetorProdutos.findIndex(indice => indice === id)
    requisitarCarrinho("DELETE", JSON.stringify({
        id: id
    }), (retorno) => {

        console.log(retorno.data)
        vetorProdutos.splice(index,1);
        let dados = new FormData(formPedido)
        //zerando os campos antes da listagem
        tablePedido.innerHTML = ""
        txtitem.value = ""
        txtvalor.value = ""
        //ele repete a listagem até usar todos ID's armazenados no array
        for(i = 0; i < vetorProdutos.length; i++){
            txtitem.value = retorno.data['quantidade_total']
            txtvalor.value = "R$ "+ retorno.data['preco_total'].toFixed(2)
            tablePedido.innerHTML += `
            <tr>
                <th scope="row">${retorno.data[vetorProdutos[i]].nome}</th>
                <td>${retorno.data[vetorProdutos[i]].quantidade}</td>
                <td>R$ ${retorno.data[vetorProdutos[i]].preco.toFixed(2)}</td>
                <td class="text-center" style="color:var(--dourado);"><a href="javascript:remover(${vetorProdutos[i]})"> <i class="bi bi-trash"></i> </a> </td>
            </tr>
            `
        }

        
    })
}