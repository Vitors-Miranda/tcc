const delivery = document.getElementById("switchDelivery")
const pix = document.getElementById("pix")

delivery.addEventListener("click", ()=>{
    if(delivery.checked){
        pix.style= " display:block;"
    }else{
        pix.style= " display:none;"
    }
})