
const funcionariolink = "http://"+EnderecoLink+"public_html/api/funcionario/"
function getFuncionarios(metodo, funcao) {
    fetch(funcionariolink, {
        method: metodo
    }).then(responseFuncionarios => responseFuncionarios.json()).then(
        (responseFuncionarios) => {
            funcao(responseFuncionarios)
        }
    )
}
getFuncionarios("GET", (resposta) => {
    let funcionarioTable = document.getElementById('funcTable')
    console.log(resposta)
    funcionarioTable.innerHTML = "";
    if (Array.isArray(resposta.data)) {
        resposta.data.forEach(funcionario => {
            funcionarioTable.innerHTML = `
                <tr>
                    <td style='text-align:center'>
                        ${funcionario.nome}
                    </td>
                    <td style='text-align:center'>
                        ${funcionario.online == true ? "Online" : "Offline"}
                    </td>
                    <td style='text-align:center'>
                            <a href='${funcionario.perfil}'>
                                <i class="bi bi-person-square">
                                </i>
                            </a>
                    </td>
                    <td style='text-align:center'>
                        <a href='#' style='red'>
                            <i class="bi bi-trash-fill" id='btnExcluir' cod=${funcionario.codigo}">
                            </i>
                        </a>
                    </td>
                </tr>
            `
        })
    } else {
        funcionarioTable.innerHTML = "<p style='text-align:center'>Nenhum profissional encontrado</p>"
    }
})
