const empresaLink = "http://"+EnderecoLink+"public_html/api/estabelecimento/"

const nomeEst = document.getElementById("nomeEst")
const codigo = document.getElementById("codigo")
const pix = document.getElementById("pix")
const subdominio = document.getElementById("subdomain")
const btnsite = document.getElementById("btnsite")

function ListarDadosEmpresa(metodo, funcao){
    fetch(empresaLink, {
        method: metodo
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
document.addEventListener("DOMContentLoaded", ()=>{
    listarEmpresa()
})  

function listarEmpresa(){
    ListarDadosEmpresa("GET", (retorno) => {
        nomeEst.value = retorno.data.estabelecimento.nome
        codigo.value = retorno.data.estabelecimento.invite_code
        pix.value = retorno.data.estabelecimento.pix_key
        subdominio.value = retorno.data.estabelecimento.subdominio    
        btnsite.addEventListener("click", ()=>{
            let sub = retorno.data.estabelecimento.subdominio
            window.open(`cliente.html?${sub}`, '_blank')
        })
    })
}
