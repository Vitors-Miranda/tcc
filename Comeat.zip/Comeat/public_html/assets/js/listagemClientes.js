let url = window.location.href
let parametro = url.split("?")

const productLink = "http://" +  EnderecoLink+"public_html/api/cliente/"+parametro[1]
function ListarProdutos(metodo, funcao) {
    fetch(productLink, {
        method: metodo
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
const cards = document.getElementById("cards")

//listando o carrinho de compra quando o usuário atualiza a página
document.addEventListener("DOMContentLoaded", () => {
    requisitarPedido("GET", null, (retorno) => {
        if(retorno.data != null){
        tablePedido.innerHTML = ""
        txtitem.value = ""
        txtvalor.value = ""

        requisitarPedido("POST", null, (retorno) => {
        //ele repete a listagem até usar todos ID's armazenados no array
        for(i = 0; i < vetorProdutos.length; i++){
            txtitem.value = retorno.data['quantidade_total']
            txtvalor.value = retorno.data['preco_total']
            tablePedido.innerHTML += `
            <tr>
                <th scope="row">${retorno.data[vetorProdutos[i]].nome}</th>
                <td>${retorno.data[vetorProdutos[i]].quantidade}</td>
                <td>R$ ${retorno.data[vetorProdutos[i]].preco.toFixed(2)}</td>
            </tr>
            `
        }

        })
        }
    })

    ListarProdutos("GET", (retorno) => {
        if (Array.isArray(retorno.data)) {
            retorno.data.forEach(element => {
                let caminhoArray = element.caminho_imagem.split("/")
                let caminho = `../../img/${caminhoArray[4]}/${caminhoArray[5]}`
                cards.innerHTML+=`
            <div class='card' id='card'>
                <a href="javascript:pedido(${element.id_produto}, '${element.nome_produto}', '${caminho}', ${element.preco})">
                    <img src='${caminho}' class='card-img-top' alt='...'>
                    <div class='card-body'>
                        <p class='card-text'> ${element.nome_produto} 
                        </p>
                    </div> 
                    <div class="card-footer text-muted"style='font-size:0.8rem'>
                    R$ ${element.preco} 
                    <input type='hidden' value='${element.id_produto}'>
                    </div>
                </a>
            </div>`
            })
        } else {
            alert(retorno.data)
        }
    })
})  