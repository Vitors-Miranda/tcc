const EstInfoLink = "http://"+EnderecoLink+"public_html/api/estInfo/" +parametro[1]
const NomeEstabelecimento = document.getElementById("NomeEstabelecimento")
const pixKey = document.getElementById("pixKey");

function requisitarEstInfo(metodo, dados, funcao) {
    fetch(EstInfoLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}

document.addEventListener("DOMContentLoaded", ()=>{
    requisitarEstInfo("GET", null, (retorno)=>{
        NomeEstabelecimento.innerHTML = retorno.data.nome.toUpperCase()
        pixKey.value = retorno.data.pix_key
    })
})