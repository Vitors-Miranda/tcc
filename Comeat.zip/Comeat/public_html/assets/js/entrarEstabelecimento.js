const btnEntrarEstabelecimento = document.getElementById("btnentrar")
const inviteLink = "http://"+EnderecoLink+"public_html/api/Invite"
btnEntrarEstabelecimento.addEventListener("click", () => {
    dados = new FormData
    dados.append("code", document.getElementById("entrainput").value)

    entryByCode(dados, "POST", (response) => {
        if (response.data) {
            alert("sucesso ao entrar")
            window.location.href = "home.html"
        } else {
            alert("Estabelecimento não encontrado")
        }
    })
})


function entryByCode(dados, metodo, funcao) {
    fetch(inviteLink, {
        method: metodo,
        body: dados
    }).then(response => response.json()).then(
        (response) => {
            funcao(response)
        }
    )
}