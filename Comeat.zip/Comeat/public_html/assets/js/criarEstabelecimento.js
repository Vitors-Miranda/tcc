//FormCreate
const CriarstabelecimentoLink = "http://"+EnderecoLink+"public_html/api/estabelecimento/"
function requisitarEstabelecimento(metodo, dados, funcao) {
    fetch(CriarstabelecimentoLink, {
        method: metodo,
        body: dados
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}
function verificarEstabelecimento(metodo, funcao) {
    fetch(CriarstabelecimentoLink, {
        method: metodo
    }).then(resposta => resposta.json()).then(
        (retorno) => {
            funcao(retorno)
        }
    )
}

const formularioCreate = document.querySelector("#FormCreate")

document.addEventListener("DOMContentLoaded", () => {
    verificarEstabelecimento("GET", (retorno) => {
        console.log(retorno.data)
        if (retorno.data.cadastrado == 1) {
            modalElement.hide()
        } else {
            modalElement.show()
        }
    })
})

formularioCreate.addEventListener("submit", (evento) => {
    modalElement.hide()
    evento.preventDefault()
    let dados = new FormData(formularioCreate)
    requisitarEstabelecimento("POST", dados, (retorno) => {
        toastbody.innerHTML = retorno.data
        toastElement.show()
    })
})