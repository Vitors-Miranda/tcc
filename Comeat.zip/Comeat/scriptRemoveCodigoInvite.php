<?php

require_once __DIR__ . "/Config/config.php";



while (true) {
    $objRemove = new RemoveInviteCode();
    $objRemove->removeCode();
    sleep(1);
}


class RemoveInviteCode
{
    public function removeCode()
    {
        $connPDO = new \PDO(DBDRIVE . ':host=' . DBHOST . ';dbname=' . DBNAME, DBUSER, DBPASS);
        $sql = "UPDATE estabelecimentos SET data_remocao_codigo_convite = NULL  WHERE data_remocao_codigo_convite <= NOW()";
        $stmt = $connPDO->prepare($sql);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            echo "Código Removido";
        }
    }
}
