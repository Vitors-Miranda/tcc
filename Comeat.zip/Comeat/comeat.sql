-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29-Nov-2022 às 00:53
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `comeat`
--
CREATE DATABASE IF NOT EXISTS `comeat` DEFAULT CHARACTER SET utf8 COLLATE utf8_swedish_ci;
USE `comeat`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estabelecimentos`
--

CREATE TABLE `estabelecimentos` (
  `id_estabelecimento` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `pix_key` varchar(200) DEFAULT NULL,
  `pix_type` int(1) DEFAULT NULL,
  `invite_code` varchar(50) DEFAULT NULL,
  `subdominio` varchar(50) DEFAULT NULL,
  `data_remocao_codigo_convite` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Extraindo dados da tabela `estabelecimentos`
--

INSERT INTO `estabelecimentos` (`id_estabelecimento`, `nome`, `pix_key`, `pix_type`, `invite_code`, `subdominio`, `data_remocao_codigo_convite`) VALUES
(1, 'pimba', NULL, NULL, 'C183', NULL, NULL),
(2, 'pimba', 'vitorsmiranda31@gmail.com', NULL, 'C183', 'coxinhas', NULL),
(3, 'empresa 1', NULL, NULL, 'C2593', 'pimba', '2022-11-19 16:49:35');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido`
--

CREATE TABLE `pedido` (
  `id_pedido` int(11) NOT NULL,
  `data` datetime DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `delivery` tinyint(1) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `telefone` varchar(15) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `logradouro` varchar(50) DEFAULT NULL,
  `numero` varchar(10) DEFAULT NULL,
  `fk_empresa_id` int(11) NOT NULL,
  `Feito` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Extraindo dados da tabela `pedido`
--

INSERT INTO `pedido` (`id_pedido`, `data`, `valor`, `delivery`, `nome`, `telefone`, `bairro`, `logradouro`, `numero`, `fk_empresa_id`, `Feito`) VALUES
(53, '2022-11-28 20:07:02', '8.00', 0, 'Ronaldo', '15991602629', '', '', '', 2, 0),
(54, '2022-11-28 20:32:53', '84.00', 1, 'Priscila', '1599178452', 'Jardim', 'sim', '110', 2, 0),
(52, '2022-11-28 20:05:13', '12.00', 0, 'Vitor', '15991602629', '', '', '', 2, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id_produto` int(11) NOT NULL,
  `id_estabelecimento` int(11) NOT NULL,
  `id_usuario_cadastrou` int(11) NOT NULL,
  `id_produto_variacoes` int(11) DEFAULT NULL,
  `nome_produto` varchar(100) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `preco` float(8,2) NOT NULL,
  `data_ultiima_alteracao` datetime DEFAULT current_timestamp(),
  `data_delecao` datetime DEFAULT NULL,
  `caminho_imagem` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id_produto`, `id_estabelecimento`, `id_usuario_cadastrou`, `id_produto_variacoes`, `nome_produto`, `descricao`, `preco`, `data_ultiima_alteracao`, `data_delecao`, `caminho_imagem`) VALUES
(20, 1, 1, NULL, 'isso', 'a', 2.00, '2022-10-18 23:56:26', NULL, '//'),
(21, 3, 3, NULL, 'produto 1', 'teste', 3.00, '2022-10-20 21:39:23', NULL, 'C:xampphtdocs	cc2AppModels/../../img//1666312763.png'),
(39, 2, 2, NULL, 'coxinha', '', 3.00, '2022-11-28 18:54:28', NULL, 'C:xampphtdocsComeatAppModels/../../img/2/1669675485.webp'),
(38, 2, 2, NULL, 'lanche', '', 2.00, '2022-11-28 18:53:51', NULL, 'C:xampphtdocsComeatAppModels/../../img/2/1669675494.webp');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos_variacoes`
--

CREATE TABLE `produtos_variacoes` (
  `id_produto_variacao` int(11) NOT NULL,
  `id_variacao` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto_pedido`
--

CREATE TABLE `produto_pedido` (
  `id_pedido_produto` int(11) NOT NULL,
  `fk_pedido_id` int(11) NOT NULL,
  `fk_produto_id` int(11) NOT NULL,
  `qtd` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Extraindo dados da tabela `produto_pedido`
--

INSERT INTO `produto_pedido` (`id_pedido_produto`, `fk_pedido_id`, `fk_produto_id`, `qtd`) VALUES
(66, 54, 38, 42),
(65, 53, 38, 4),
(64, 52, 38, 3),
(63, 52, 39, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `sobrenome` varchar(120) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(40) NOT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `online` tinyint(1) DEFAULT NULL,
  `id_estabelecimento` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `sobrenome`, `email`, `senha`, `admin`, `online`, `id_estabelecimento`) VALUES
(1, 'vitao', 'Miranda', 'vitin@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, 1),
(2, 'vitor', 'souza2', 'vitao@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, 2),
(3, 't', 't', 't@t.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, 3),
(4, 't2', 't2', 't2@t.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `variacoes`
--

CREATE TABLE `variacoes` (
  `id_variacao` int(11) NOT NULL,
  `texto_variacao` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `id_venda` int(11) NOT NULL,
  `id_profissional` int(11) NOT NULL,
  `id_estabelecimento` int(11) NOT NULL,
  `data_solicitacao_venda` datetime NOT NULL,
  `data_venda_concluida` datetime NOT NULL,
  `data_cancelamento_venda` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas_produtos`
--

CREATE TABLE `vendas_produtos` (
  `id_venda_produto` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `id_venda` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `estabelecimentos`
--
ALTER TABLE `estabelecimentos`
  ADD PRIMARY KEY (`id_estabelecimento`);

--
-- Índices para tabela `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id_pedido`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id_produto`);

--
-- Índices para tabela `produtos_variacoes`
--
ALTER TABLE `produtos_variacoes`
  ADD PRIMARY KEY (`id_produto_variacao`);

--
-- Índices para tabela `produto_pedido`
--
ALTER TABLE `produto_pedido`
  ADD PRIMARY KEY (`id_pedido_produto`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `estabelecimentos`
--
ALTER TABLE `estabelecimentos`
  MODIFY `id_estabelecimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de tabela `produto_pedido`
--
ALTER TABLE `produto_pedido`
  MODIFY `id_pedido_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
